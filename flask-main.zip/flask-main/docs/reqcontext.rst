:orphan:

The Request Context
===================

Obsolete, see :doc:`/appcontext` instead.
